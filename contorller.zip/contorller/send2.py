# coding=utf-8
import socket
from threading import Thread
import json
import time
from node import nodes
import cv2
import numpy as np
import os


def allOnTick():
    while 1:
        for k, v in nodeDict:
            v.onTick()
        time.sleep(9.3)


def sendAll():
    while 1:
        paramArrary = []
        for k, v in nodeDict.items():
            v.onTick()
            paramArrary.append({"Name": v.getName(), "Value": v.getValue()})
        jsonResult['Parameter'] = paramArrary
        cli.sendto((bytes(json.dumps(jsonFinal).encode('utf-8'))), ipaddress)
        time.sleep(0.3)


barcount = 40

secPerWorld = 0.5
# ms


# expressionList = []
expressionDict = {}


def laodExpression():
    path = 'resource\\sigleNode\\'
    files = os.listdir(path)
    print(files)
    for file in files:
        pos = path + file
        tmplist2 = []
        with open(pos, 'r') as fin:
            rdline = fin.readlines()
            for lines in rdline:
                tmplist = lines.strip().split('\t')
                tmplist2.append(nodes(tmplist[0]))
                tmplist2[-1].setValue(tmplist[1])
            # expressionList.append([file.split('.')[0], tmplist2])
            expressionDict[file.split('.')[0]] = tmplist2


laodExpression()


def both(s):
    s = s.replace("Left", "")
    s = s.replace("Right", "")
    return s


def startSend():
    # while True:
    #     paramArrary = []
    #     for k, v in nodeDict.items():
    #         paramArrary.append({"Name": v.getName(), "Value": v.getValue()})
    #     jsonResult['Parameter'] = paramArrary
    #     cli.sendto((bytes(json.dumps(jsonFinal).encode('utf-8'))), ipaddress)
    # wordlist = [['r', 'u'], ['g', 'u', 'o'], ['f', 'e', '-n'],
    #             ['sh', 'o', 'u'], ['t', 'a', 'i'], ['f', 'u'],
    #             ['z', 'a'], ['0']]

    wordlist = [['m', 'i', 'a', '-n'], ['x', 'i', 'a', 'ng'], ['w', 'e', '-n', ],
                ['d', 'a'], ['x', 'i', ], ['t', 'o', '-n'],
                ['d', 'e'], ['x', 'v'], ['n', 'i'], ['r', 'e', '-n'],
                ['j', 'i'], ['sh', 'u'], ['y', 'a', '-n'], ['j', 'i', '-o'],
                ['y', 'v'], ['y', 'i', 'ng'], ['y', 'o', 'ng'], ['0'], ['0'], ['0']]
    '''面向问答系统的虚拟人技术研究与应用'''
    # wordlist = [['zh', 'e'], ['g', 'e'], ['x', 'a', 'o', '-o'],
    #             ['g', 'u', 'o', '-o'], ['0'], ['0'], ['0'], ['0']]
    nowtime = time.time()
    endtime = time.time()

    for word in wordlist:
        num = len(word)
        index = 0
        while index < num:
            nowtime = time.time()
            print(word[index])
            if nowtime > endtime:
                tar = word[index]
                tar = expressionDict[tar]
                for temp in tar:
                    # nodeDict[temp.getName()].setTarget(float(temp.getValue()), 1)
                    nodeDict[temp.getName()].setTarget(float(temp.getValue()), secPerWorld / num)
                index += 1
                endtime += secPerWorld / num
            paramArrary = []
            for k, v in nodeDict.items():
                v.onTick()
                paramArrary.append({"Name": v.getName(), "Value": v.getValue()})
            jsonResult['Parameter'] = paramArrary
            cli.sendto((bytes(json.dumps(jsonFinal).encode('utf-8'))), ipaddress)
            time.sleep(0.03)

            # print(jsonFinal)
            # time.sleep(3)


# init
ipaddress = ("192.168.1.152", 11111)
cli = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

jsonResult = {}
jsonFinal = {}

headDict = {}

jsonFinal['android'] = jsonResult

nodeDict = {}

with open('resource\\allnodelist.txt', 'r') as f:
    templist = f.readlines()
    for i in templist:
        nodeDict[i.strip()] = nodes(i.strip())
        # nodeDict[i.strip()].setTarget(1)
        # if both(i.strip()) not in namelist:
        #     namelist.append(both(i.strip()))

while 1:
    startSend()


