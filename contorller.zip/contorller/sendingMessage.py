import node
import socket
# init
ipaddress = ("192.168.1.152", 11111)
cli = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

jsonResult = {}
jsonFinal = {}
headDict = {}

jsonFinal['android'] = jsonResult
