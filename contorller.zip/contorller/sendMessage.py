import socket
from threading import Thread
import json
import time
import node



# init
ipaddress = ("192.168.1.152", 11111)
cli = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
paramArrary = {}

boneArrary = []
jsonResult = {}
jsonFinal = {}

headBone = {'Name': "Head",
            'Parent': -1,
            'Location': [0, 0, 0],
            'Rotation': [0, 0, 0, 1],  # 四元数旋转
            'Scale': [1, 1, 1]}

boneArrary.append(headBone)
jsonResult['Bone'] = boneArrary
jsonFinal['android'] = jsonResult

"""change testjson to control metahuman expression"""

browDownRight = 0
browInnerUpRight = 0
browOuterUpRight = 0
browOuterUpLeft = 0
browInnerUpLeft = 0
browDownLeft = 0

browlist = [browDownRight, browInnerUpRight, browOuterUpRight,
            browOuterUpLeft, browInnerUpLeft, browDownLeft]

noseSneerRight = 0
noseSneerLeft = 0

noselist = [noseSneerRight, noseSneerLeft]

mouthUpperUpLeft = 0
mouthSmileLeft = 0
mouthLeft = 0
mouthFrownLeft = 0
mouthLowerDownLeft = 0

mouthLowerDownRight = 0
mouthFrownRight = 0
mouthRight = 0
mouthSmileRight = 0
mouthUpperUpRight = 0

mouthPucker = 0
mouthRollUpper = 0
mouthShrugUpper = 0
mouthFunnel = 0
mouthRollLower = 0

mouthlist = [mouthUpperUpLeft, mouthSmileLeft, mouthLeft,
             mouthFrownLeft, mouthLowerDownLeft,
             mouthLowerDownRight, mouthFrownRight, mouthRight,
             mouthSmileRight, mouthUpperUpRight,
             mouthPucker, mouthRollUpper, mouthShrugUpper,
             mouthFunnel, mouthRollLower]

jawRight = 0
jawLeft = 0
jawOpen = 0
cheekPuff = 0
tongueOut = 0

jawlist = [jawRight, jawLeft, jawOpen, cheekPuff, tongueOut]

eyeLookDownRight = 0
eyeLookInRight = 0
eyeLookOutRight = 0
eyeLookUpRight = 0
eyeWideRight = 0

eyeSquintRight = 0
eyeBlinkRight = 0
eyeBlinkLeft = 0
eyeSquintLeft = 0
eyeWideLeft = 0

eyeLookUpLeft = 0
eyeLookOutLeft = 0
eyeLookInLeft = 0
eyeLookDownLeft = 0

eyelist = [eyeLookDownRight, eyeLookInRight, eyeLookOutRight,
           eyeLookUpRight, eyeWideRight, eyeSquintRight,
           eyeBlinkRight, eyeBlinkLeft, eyeSquintLeft,
           eyeWideLeft, eyeLookUpLeft, eyeLookOutLeft,
           eyeLookInLeft, eyeLookDownLeft]

allList = [browlist, eyelist, noselist, mouthlist, jawlist]
paramArrary = [{"Name": "browOuterUpLeft", "Value": browOuterUpLeft},
               {"Name": "browInnerUpLeft", "Value": browInnerUpLeft},
               {"Name": "browDownLeft", "Value": browDownLeft},
               {"Name": "eyeBlinkLeft", "Value": eyeBlinkLeft},
               {"Name": "eyeSquintLeft", "Value": eyeSquintLeft},
               {"Name": "eyeWideLeft", "Value": eyeWideLeft},
               {"Name": "eyeLookUpLeft", "Value": eyeLookUpLeft},
               {"Name": "eyeLookOutLeft", "Value": eyeLookOutLeft},
               {"Name": "eyeLookInLeft", "Value": eyeLookInLeft},
               {"Name": "eyeLookDownLeft", "Value": eyeLookDownLeft},
               {"Name": "noseSneerLeft", "Value": noseSneerLeft},
               {"Name": "mouthUpperUpLeft", "Value": mouthUpperUpLeft},
               {"Name": "mouthSmileLeft", "Value": mouthSmileLeft},
               {"Name": "mouthLeft", "Value": mouthLeft},
               {"Name": "mouthFrownLeft", "Value": mouthFrownLeft},
               {"Name": "mouthLowerDownLeft", "Value": mouthLowerDownLeft},
               {"Name": "jawLeft", "Value": jawLeft},
               {"Name": "cheekPuff", "Value": cheekPuff},
               {"Name": "mouthShrugUpper", "Value": mouthShrugUpper},
               {"Name": "mouthFunnel", "Value": mouthFunnel},
               {"Name": "mouthRollLower", "Value": mouthRollLower},
               {"Name": "jawOpen", "Value": jawOpen},
               {"Name": "tongueOut", "Value": tongueOut},
               {"Name": "mouthPucker", "Value": mouthPucker},
               {"Name": "mouthRollUpper", "Value": mouthRollUpper},
               {"Name": "jawRight", "Value": jawRight},
               {"Name": "mouthLowerDownRight", "Value": mouthLowerDownRight},
               {"Name": "mouthFrownRight", "Value": mouthFrownRight},
               {"Name": "mouthRight", "Value": mouthRight},
               {"Name": "mouthSmileRight", "Value": mouthSmileRight},
               {"Name": "mouthUpperUpRight", "Value": mouthUpperUpRight},
               {"Name": "noseSneerRight", "Value": noseSneerRight},
               {"Name": "eyeLookDownRight", "Value": eyeLookDownRight},
               {"Name": "eyeLookInRight", "Value": eyeLookInRight},
               {"Name": "eyeLookOutRight", "Value": eyeLookOutRight},
               {"Name": "eyeLookUpRight", "Value": eyeLookUpRight},
               {"Name": "eyeWideRight", "Value": eyeWideRight},
               {"Name": "eyeSquintRight", "Value": eyeSquintRight},
               {"Name": "eyeBlinkRight", "Value": eyeBlinkRight},
               {"Name": "browDownRight", "Value": browDownRight},
               {"Name": "browInnerUpRight", "Value": browInnerUpRight},
               {"Name": "browOuterUpRight", "Value": browOuterUpRight}]
jsonResult['Parameter'] = paramArrary

"""================================================================================"""


def loop():
    while 1:
        # cli.sendto((bytes(json.dumps(jsonResult).encode('utf-8'))), ipaddress)
        # print(jsonResult)
        # time.sleep(0.05)  # 20hz
        print(allList)
        time.sleep(0.1)


def changeAll():
    # for k in allList:
    #     for i in k:
    #         for j in range(10):
    #             i = i+1111
    #             time.sleep(0.1)
    #         for j in range(10):
    #             i = i-1111
    #             time.sleep(0.1)
    global browlist
    while 1:
        browlist[1] = browlist[1] + 10
        browInnerUpRight = browInnerUpRight + 100
        time.sleep(0.1)


t1 = Thread(target=loop)
t2 = Thread(target=changeAll)

t2.start()
t1.start()
