# coding=utf-8
import socket
from threading import Thread
import json
import time
import cv2
import numpy as np
import os
from sendingMessage import *
from node import *
import random


def pitchHead(num=0.25, time=0.5, eyeDirection=1):
    """

    :param num: 幅度
    :param time: 用时
    :param eyeDirection: 1：眼睛保持看向镜头
                        -1：眼睛看向转头方向
                        0：眼睛直视头部前方
    :return:
    """
    nodeDict['HeadPitch'].setTarget(num, time)
    if num > 0:
        nodeDict['eyeLookDownRight'].setTarget(num * eyeDirection, time)
        nodeDict['eyeLookDownLeft'].setTarget(num * eyeDirection, time)
        nodeDict['eyeLookUpRight'].setTarget(0, time)
        nodeDict['eyeLookUpLeft'].setTarget(0, time)
    else:
        nodeDict['eyeLookDownRight'].setTarget(0, time)
        nodeDict['eyeLookDownLeft'].setTarget(0, time)
        nodeDict['eyeLookUpRight'].setTarget(num * eyeDirection, time)
        nodeDict['eyeLookUpLeft'].setTarget(num * eyeDirection, time)


def yawHead(num=0.25, time=0.5, eyeDirection=1):
    """

    :param num: 幅度
    :param time: 用时
    :param eyeDirection: 1：眼睛保持看向镜头
                        -1：眼睛看向转头方向
                        0：眼睛直视头部前方
    :return:
    """
    nodeDict['HeadYaw'].setTarget(num, time)
    if num > 0:
        nodeDict['eyeLookOutRight'].setTarget(num * eyeDirection, time)
        nodeDict['eyeLookInLeft'].setTarget(num * eyeDirection, time)
        nodeDict['eyeLookUpRight'].setTarget(0, time)
        nodeDict['eyeLookUpLeft'].setTarget(0, time)
    else:
        nodeDict['eyeLookOutRight'].setTarget(0, time)
        nodeDict['eyeLookInLeft'].setTarget(0, time)
        nodeDict['eyeLookInRight'].setTarget(num * eyeDirection, time)
        nodeDict['eyeLookOutLeft'].setTarget(num * eyeDirection, time)


def controlHead():
    while 1:
        # 生成4随机数，前2是yaw pitch 三是roll值，四是眼睛是否看向中间，五是保持时间。
        pitchNum = (random.random())/4
        yawNum = (random.random()-0.5)/2
        rollNum = (random.random()-0.5)/5
        eyeDirNum = random.randint(-1, 1)
        timeNum = random.random()*5+1
        usingTime = (timeNum / 10) + 0.1
        yawHead(yawNum, usingTime, eyeDirNum)
        pitchHead(pitchNum, usingTime, eyeDirNum)
        nodeDict['HeadRoll'].setTarget(rollNum, usingTime)
        time.sleep(timeNum)


def RandomMove():
    while 1:
        #头部轻微晃动
        time.sleep(0.05+random.random())
        rty = random.random()-0.5
        rtp = random.random()-0.5
        nodeDict['HeadYaw'].setRandTar(rty)
        nodeDict['HeadPitch'].setRandTar(rtp)
        # nodeDict['HeadRoll'].setValue(nodeDict['HeadRoll'].getValue()+(random-0.5)/20)


def allOnTick():
    while 1:
        for k, v in nodeDict:
            v.onTick()
        time.sleep(0.03)


def sendAll():
    while 1:
        paramArrary = []
        for k, v in nodeDict.items():
            # everything on tick
            v.onTick()
            paramArrary.append({"Name": v.getName(), "Value": v.getValue()})
        jsonResult['Parameter'] = paramArrary
        cli.sendto((bytes(json.dumps(jsonFinal).encode('utf-8'))), ipaddress)
        print(jsonFinal)
        time.sleep(0.03)


# 每个字用时
secPerWorld = 0.3
# 设置口型权重
weight = 1
if secPerWorld < 0.5:
    weight = secPerWorld * 2


def laodExpression(path, dic):
    # 导入口型字典
    # path = 'resource\\sigleNode\\'
    files = os.listdir(path)
    print(files)
    for file in files:
        pos = path + file
        tmplist2 = []
        with open(pos, 'r') as fin:
            rdline = fin.readlines()
            for lines in rdline:
                tmplist = lines.strip().split('\t')
                tmplist2.append(nodes(tmplist[0]))
                tmplist2[-1].setValue(tmplist[1])
            # expressionList.append([file.split('.')[0], tmplist2])
            dic[file.split('.')[0]] = tmplist2
            # expressionDict[file.split('.')[0]] = tmplist2


# 音素对应口型的字典
expressionDict = {}
laodExpression(path='resource\\sigleNode\\', dic=expressionDict)

# 头部运动对应字典
headRollDict = {}


def both(s):
    # 同时控制左右
    s = s.replace("Left", "")
    s = s.replace("Right", "")
    return s


def newTargetMouth():
    wordlist = [['m', 'i', 'a', '-n'], ['x', 'i', 'a', 'ng'], ['w', 'e', '-n', ],
                ['d', 'a'], ['x', 'i', ], ['t', 'o', '-n'],
                ['d', 'e'], ['x', 'v'], ['n', 'i'], ['r', 'e', '-n'],
                ['j', 'i'], ['sh', 'u'], ['y', 'a', '-n'], ['j', 'i', '-o'],
                ['y', 'v'], ['y', 'i', 'ng'], ['y', 'o', 'ng'], ['0'], ['0'], ['0']]
    while 1:
        endtime = time.time()
        for word in wordlist:
            num = len(word)
            index = 0

            while index < num:
                nowtime = time.time()
                print(word[index])
                if nowtime > endtime:
                    tar = word[index]
                    tar = expressionDict[tar]
                    for temp in tar:
                        nodeDict[temp.getName()].setTarget(float(temp.getValue()) * weight, secPerWorld / num)
                    index += 1
                    endtime += secPerWorld / num
                time.sleep(0.03)


t1 = Thread(target=newTargetMouth)
t2 = Thread(target=sendAll)
t3 = Thread(target=controlHead)
t4 = Thread(target=RandomMove)

t1.start()
t2.start()
t3.start()
t4.start()
