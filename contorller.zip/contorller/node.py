# coding=utf-8
fps = 24  # 每秒24贞
import time


class nodes:
    def __init__(self, name):
        self.name = name
        self.value = 0.001
        self.target = 0.001
        self.etime = 0.01
        self.otime = 0.01
        # oletime
        self.randValue = 0.0001
        self.randTar = 0.0001
        # 细微随机动作

    def getName(self):
        return self.name

    def getValue(self):
        return float(self.value) + self.randValue

    def setRandom(self, randv):
        # 设置仅设置百分之一
        self.randValue = randv / 100

    def setRandTar(self, tar):
        # 设置仅设置百分之一
        # self.randTar = tar / 100
        self.randTar = tar/20

    def setTarget(self, tar, e):
        self.target = tar
        self.etime = e + time.time()

    def setValue(self, val):
        self.value = val

    def onTick(self):
        nntime = time.time()
        otime = self.otime
        if self.etime > self.otime:
            self.value = (self.value +
                          (self.target - self.value) *
                          ((nntime - otime) /
                           (self.etime - self.otime)))
        self.randValue += (self.randTar-self.randValue)/10
        if self.value > 1:
            self.value = 1
        self.otime = nntime

    def loopToTest(self):
        if self.target == 1:
            self.value += 0.05
        else:
            self.value -= 0.05
        if self.value > 1:
            self.target = 0
        if self.value < 0:
            self.target = 1


nodeDict = {}
with open('resource\\allnodelist.txt', 'r') as f:
    templist = f.readlines()
    for i in templist:
        nodeDict[i.strip()] = nodes(i.strip())
