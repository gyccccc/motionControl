# coding=utf-8
import socket
from threading import Thread
import json
import time
from node import nodes
import cv2
import numpy as np
import os

barcount = 40


def save(x):
    if x == 1:
        number = cv2.getTrackbarPos('NUMBER', 'mouthImg')
        with open('resource\\tempSigleNode\\' + str(number) + '.txt', 'w') as fout:
            for k, v in nodeDict.items():
                if "mouth" in v.getName() or "jaw" in v.getName():
                    fout.write(v.getName())
                    fout.write('\t')
                    fout.write(str(v.getValue()))
                    fout.write('\n')
        cv2.setTrackbarPos('button', 'mouthImg', 0)
        cv2.setTrackbarPos('NUMBER', 'mouthImg', number + 1)


def saveHead(x):
    if x == 1:
        number = cv2.getTrackbarPos('NUMBER', 'eyeImg')
        with open('resource\\tempSigleNode\\' + str(number) + '.txt', 'w') as fout:
            for k, v in nodeDict.items():
                if "eye" in v.getName() or "Head" in v.getName():
                    fout.write(v.getName())
                    fout.write('\t')
                    fout.write(str(v.getValue()))
                    fout.write('\n')
        cv2.setTrackbarPos('button', 'eyeImg', 0)
        cv2.setTrackbarPos('NUMBER', 'eyeImg', number + 1)


expressionList = []


def laodExpression():
    path = 'resource\\sigleNode\\'
    files = os.listdir(path)
    print(files)
    for file in files:
        pos = path + file
        tmpdict = []
        with open(pos, 'r') as fin:
            rdline = fin.readlines()
            for lines in rdline:
                tmplist = lines.strip().split('\t')
                tmpdict.append(nodes(tmplist[0]))
                tmpdict[-1].setValue(tmplist[1])
            expressionList.append([file.split('.')[0], tmpdict])


laodExpression()

headList = []


def laodHead():
    path = 'resource\\HeadNode\\'
    files = os.listdir(path)
    print(files)
    for file in files:
        pos = path + file
        tmpdict = []
        with open(pos, 'r') as fin:
            rdline = fin.readlines()
            for lines in rdline:
                tmplist = lines.strip().split('\t')
                tmpdict.append(nodes(tmplist[0]))
                tmpdict[-1].setValue(tmplist[1])
            headList.append([file.split('.')[0], tmpdict])


laodHead()


def setToZip(x):
    if x == 1:
        number = cv2.getTrackbarPos('zip', 'mouthImg')
        if number > len(expressionList):
            return
        print(expressionList[number][0])
        for tmpnode in expressionList[number][1]:
            nodeDict[tmpnode.getName()].setValue(tmpnode.getValue())
            cv2.setTrackbarPos(tmpnode.getName(), 'mouthImg', int(float(tmpnode.getValue()) * 40))

        cv2.setTrackbarPos('setToZip', 'mouthImg', 0)


def setToZipHead(x):
    if x == 1:
        number = cv2.getTrackbarPos('zip', 'eyeImg')
        if number > len(HeadList):
            return
        print(HeadList[number][0])
        for tmpnode in HeadList[number][1]:
            nodeDict[tmpnode.getName()].setValue(tmpnode.getValue())
            cv2.setTrackbarPos(tmpnode.getName(), 'eyeImg', int(float(tmpnode.getValue()) * 40))

        cv2.setTrackbarPos('setToZip', 'eyeImg', 0)


def both(s):
    s = s.replace("Left", "")
    s = s.replace("Right", "")
    return s


def callback(object):  # 注意这里createTrackbar会向其传入参数即滑动条地址（几乎用不到），所以必须写一个参数
    pass


def showControlBar():
    global img
    img = np.zeros((300, 400, 3), np.uint8)  # 创建初始画布大小
    cv2.namedWindow('image', cv2.WINDOW_AUTOSIZE)  # 创建窗口
    img[:] = [255, 255, 255]  # 初始化画布颜色

    for k, v in nodeDict.items():
        cv2.createTrackbar(v.getName(), 'image', 0, barcount, callback)  # 好像不支持小数的滑块?记得/barcount

    while (True):
        paramArrary = []
        for k, v in nodeDict.items():
            v.setValue(cv2.getTrackbarPos(v.getName(), 'image') / barcount)  # 根据滑块值进行更新
            paramArrary.append({"Name": v.getName(), "Value": v.getValue()})
        jsonResult['Parameter'] = paramArrary
        cli.sendto((bytes(json.dumps(jsonFinal).encode('utf-8'))), ipaddress)
        time.sleep(0.03)
        if cv2.waitKey(10) & 0xFF == 27:  # 按esc退出
            break
        cv2.imshow('image', img)
    cv2.destroyAllWindows()


def showSplitlBar():
    global mouthImg, eyeImg, otherImg
    mouthImg = np.zeros((1080, 1920, 3), np.uint8)  # 创建初始画布大小
    eyeImg = np.zeros((1080, 1920, 3), np.uint8)  # 创建初始画布大小
    otherImg = np.zeros((1080, 1920, 3), np.uint8)  # 创建初始画布大小

    cv2.namedWindow('mouthImg', cv2.WINDOW_AUTOSIZE)  # 创建窗口
    cv2.namedWindow('eyeImg', cv2.WINDOW_AUTOSIZE)  # 创建窗口
    cv2.namedWindow('otherImg', cv2.WINDOW_AUTOSIZE)  # 创建窗口

    mouthImg[:] = [255, 255, 255]  # 初始化画布颜色
    eyeImg[:] = [255, 255, 255]  # 初始化画布颜色
    otherImg[:] = [255, 255, 255]  # 初始化画布颜色

    # cv2.createTrackbar('button', 'mouthImg', 0, 1, save)
    # cv2.createTrackbar('NUMBER', 'mouthImg', 0, 30, callback)
    # cv2.createTrackbar('zip', 'mouthImg', 0, 30, callback)
    # cv2.createTrackbar('setToZip', 'mouthImg', 0, 1, setToZip)

    cv2.createTrackbar('button', 'eyeImg', 0, 1, saveHead)
    cv2.createTrackbar('NUMBER', 'eyeImg', 0, 30, callback)
    cv2.createTrackbar('zip', 'eyeImg', 0, 30, callback)
    cv2.createTrackbar('setToZip', 'eyeImg', 0, 1, setToZipHead)

    """面部滑块控制"""
    for k, v in nodeDict.items():  # 设置滑块
        if "eye" in v.getName() or "brow" in v.getName():
            cv2.createTrackbar(v.getName(), 'eyeImg', 0, barcount, callback)  # 好像不支持小数的滑块?记得/barcount
        elif "mouth" in v.getName() or "jaw" in v.getName():
            cv2.createTrackbar(v.getName(), 'mouthImg', 0, barcount, callback)  # 好像不支持小数的滑块?记得/barcount
        elif "Head" in v.getName():
            cv2.createTrackbar(v.getName(), 'eyeImg', barcount, 2 * barcount, callback)  # 好像不支持小数的滑块?记得/barcount
        else:
            cv2.createTrackbar(v.getName(), 'otherImg', 0, barcount, callback)  # 好像不支持小数的滑块?记得/barcount

    while True:
        paramArrary = []
        for k, v in nodeDict.items():
            if "eye" in v.getName() or "brow" in v.getName():
                v.setValue(cv2.getTrackbarPos(v.getName(), 'eyeImg') / barcount)  # 根据滑块值进行更新
            elif "mouth" in v.getName() or "jaw" in v.getName():
                v.setValue(cv2.getTrackbarPos(v.getName(), 'mouthImg') / barcount)  # 根据滑块值进行更新
            elif "Head" in v.getName():
                v.setValue((cv2.getTrackbarPos(v.getName(), 'eyeImg') - barcount) / barcount)  # 根据滑块值进行更新
            else:
                v.setValue(cv2.getTrackbarPos(v.getName(), 'otherImg') / barcount)  # 根据滑块值进行更新
            paramArrary.append({"Name": v.getName(), "Value": v.getValue()})
        jsonResult['Parameter'] = paramArrary
        cli.sendto((bytes(json.dumps(jsonFinal).encode('utf-8'))), ipaddress)
        # print(jsonFinal)
        time.sleep(0.03)
        if cv2.waitKey(10) & 0xFF == 27:  # 按esc退出
            break
        # cv2.imshow('mouthImg', mouthImg)
        # cv2.imshow('eyeImg', eyeImg)
        # cv2.imshow('otherImg', otherImg)
        # cv2.imshow('headBoneBar', headBoneBar)
    cv2.destroyAllWindows()


# init
ipaddress = ("192.168.1.152", 11111)
cli = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
paramArrary = {}

boneArrary = []
jsonResult = {}
jsonFinal = {}

# headBone = {'Name': "Head",
#             'Parent': -1,
#             'Location': [0, 0, 0],
#             'Rotation': [0, 0, 0, 1],  # 四元数旋转
#             'Scale': [1, 1, 1]}

headDict = {}

# boneArrary = []
# boneArrary.append(headBone)
# jsonResult['Bone'] = boneArrary

jsonFinal['android'] = jsonResult

nodeDict = {}
namelist = []
with open('resource\\allnodelist.txt', 'r') as f:
    # 处理头部location rotation等
    templist = f.readlines()
    for i in templist:
        nodeDict[i.strip()] = nodes(i.strip())
        # nodeDict[i.strip()].setTarget()
        # if both(i.strip()) not in namelist:
        #     namelist.append(both(i.strip()))

print(namelist)

with open('resource\\headlist.txt', 'r') as f:
    templist = f.readlines()
    for i in templist:
        headDict[i.strip()] = nodes(i.strip())
        # headDict[i.strip()].setTarget(1)
        if both(i.strip()) not in namelist:
            namelist.append(both(i.strip()))
count = 0
# while 1:
#     paramArrary = []
#     for key, value in nodeDict.items():
#         if both(value.getName()) == namelist[count // 120]:
#             value.loopToTest()
#         paramArrary.append({"Name": value.getName(), "Value": value.getValue()})
#     jsonResult['Parameter'] = paramArrary
#     cli.sendto((bytes(json.dumps(jsonFinal).encode('utf-8'))), ipaddress)
#     print(namelist[count // 120])
#     time.sleep(0.03)
#     count += 1


showSplitlBar()
