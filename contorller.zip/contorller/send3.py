# coding=utf-8
import socket
from threading import Thread
import json
import time
# from node import nodes
import cv2
import numpy as np
import os
from sendingMessage import *
from node import *


def allOnTick():
    while 1:
        for k, v in nodeDict:
            v.onTick()
        time.sleep(0.03)




def sendAll():
    while 1:
        paramArrary = []
        for k, v in nodeDict.items():
            # everything on tick
            v.onTick()
            paramArrary.append({"Name": v.getName(), "Value": v.getValue()})
        jsonResult['Parameter'] = paramArrary
        cli.sendto((bytes(json.dumps(jsonFinal).encode('utf-8'))), ipaddress)
        # print(jsonFinal)
        time.sleep(0.03)


# 每个字用时
secPerWorld = 0.3
# 设置口型权重
weight = 1
if secPerWorld < 0.5:
    weight = secPerWorld * 2


def laodExpression(path, dic):
    # 导入口型字典
    # path = 'resource\\sigleNode\\'
    files = os.listdir(path)
    print(files)
    for file in files:
        pos = path + file
        tmplist2 = []
        with open(pos, 'r') as fin:
            rdline = fin.readlines()
            for lines in rdline:
                tmplist = lines.strip().split('\t')
                tmplist2.append(nodes(tmplist[0]))
                tmplist2[-1].setValue(tmplist[1])
            # expressionList.append([file.split('.')[0], tmplist2])
            dic[file.split('.')[0]] = tmplist2
            # expressionDict[file.split('.')[0]] = tmplist2


# 音素对应口型的字典
expressionDict = {}
laodExpression(path='resource\\sigleNode\\', dic=expressionDict)

# 头部运动对应字典
headRollDict = {}


def both(s):
    # 同时控制左右
    s = s.replace("Left", "")
    s = s.replace("Right", "")
    return s


def newTargetMouth():
    wordlist = [['m', 'i', 'a', '-n'], ['x', 'i', 'a', 'ng'], ['w', 'e', '-n', ],
                ['d', 'a'], ['x', 'i', ], ['t', 'o', '-n'],
                ['d', 'e'], ['x', 'v'], ['n', 'i'], ['r', 'e', '-n'],
                ['j', 'i'], ['sh', 'u'], ['y', 'a', '-n'], ['j', 'i', '-o'],
                ['y', 'v'], ['y', 'i', 'ng'], ['y', 'o', 'ng'], ['0'], ['0'], ['0']]
    while 1:
        endtime = time.time()
        for word in wordlist:
            num = len(word)
            index = 0

            while index < num:
                nowtime = time.time()
                print(word[index])
                if nowtime > endtime:
                    tar = word[index]
                    tar = expressionDict[tar]
                    for temp in tar:
                        nodeDict[temp.getName()].setTarget(float(temp.getValue()) * weight, secPerWorld / num)
                    index += 1
                    endtime += secPerWorld / num
                time.sleep(0.03)


t1 = Thread(target=newTargetMouth)
t2 = Thread(target=sendAll)

t2.start()
t1.start()
