# coding=utf-8
import os

filepath1 = os.getcwd()
print(filepath1)

with open("reslt.xls", 'w', encoding='gbk') as f:
    with open("input.txt", encoding="utf-8") as fin:
        lines = fin.readlines()
        for i in lines:
            index = i.rfind(' ')+1
            sub = i[index:]
            f.write(sub)


